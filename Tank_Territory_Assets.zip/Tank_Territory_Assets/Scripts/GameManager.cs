﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class GameManager : MonoBehaviour {
	public GameObject GreyTank;
	public GameObject BigGreyTank;
	public GameObject LittleGreyTank;
	public GameObject BlueTankPrefab;
	public GameObject RedTankPrefab;
	public GameObject GreenTankPrefab;
	public GameObject YellowTankPrefab;
	public GameObject Flag;
	public int numberOfTanks = 20;
	public int numberOfActiveTanks = 19;
	public float TimeLimit;
	public int PlayerCount = 1;
	public string GameMode = "LastTankStanding";// could also be "Survival"
	private bool bGameIsLive = false;
	public Dropdown dropdownGameTime;
	public Dropdown dropdownPlayerCount;
	public Dropdown dropdownAICount;
	public Dropdown dropdownGameMode;
	bool bAllPlayerDead =  false;
	bool bGameRunning = false;
	private string[,] ScoreArray = new string[4,2];//creates an array of 0 to 3 by 0 to 1. Element 0 is Scores, Element 1 is Player Colour. 
	private string strFileDataPath;
	private StreamReader srReader;
	private StreamWriter swWriter;
	private string[] HighPlayers = new string[10]; //sets up an array. The array is in fact numbered from 0 to 9.
	private string[] HighValues = new string[10];
	private GameObject BlueTank;
	private GameObject RedTank;
	private GameObject GreenTank;
	private GameObject YellowTank;
	public int BluScore = 0;
	public int RedScore = 0;
	public int GrnScore = 0;
	public int YelScore = 0;
	public Text m_MessageText;
	public Camera SplashCam;
	public Camera MainCam;
	private Camera BluCam;
	private Camera RedCam;
	private Camera GrnCam;
	private Camera YelCam;


	// Use this for initialization
	public void Start(){
		//Load up the high scores
		LoadHighScores();
		StartCoroutine (Waiting());
		print ("called init");
		//strText = File.ReadAllText();
		//print (strText);
		//HighPlayers[] = strText.ToCharArray();
		SplashCam.enabled = true;
		MainCam.enabled = false;
		ShowMainMenu ();
		//BluCam.enabled = false;
		//RedCam.enabled = false;
		//GrnCam.enabled = false;
		//YelCam.enabled = false;
		//GameObject.Find ("Blue_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
		//GameObject.Find ("Red_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
		//GameObject.Find ("Green_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
		//GameObject.Find ("Yellow_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;

		Time.timeScale = 0; //pause the game

	}

	IEnumerator Waiting(){
			yield return new WaitForSeconds (5);	
	}



	public void LoadSettings()
	{
		TimeLimit = float.Parse (dropdownGameTime.GetComponentInChildren<Text> ().text) * 60; //change the number of minutes to a timelimit, in seconds.
//		print ("-----------------");
//		print (TimeLimit.ToString ());
		PlayerCount= int.Parse(dropdownPlayerCount.GetComponentInChildren<Text> ().text);
		numberOfTanks = int.Parse(dropdownAICount.GetComponentInChildren<Text> ().text);
		if (dropdownGameMode.value == 1) {
			GameMode = "Last Tank Standing";
		}
		else {
			GameMode = "Survival";
		}
//		print (numberOfTanks);
//		print (TimeLimit);
//		print (PlayerCount);
//		print (GameMode);

		Time.timeScale = 1;
		StartUp ();
	}


	void LoadPlayerTanks (string  SpawnPointName, string TankName, ref GameObject TankPrefab, ref GameObject TankToInstantiate, ref Camera CameraToSet){
		GameObject tempSpawnPoint;

		tempSpawnPoint= GameObject.Find (SpawnPointName);
		TankToInstantiate = Instantiate (TankPrefab , tempSpawnPoint.transform.position, tempSpawnPoint.transform.rotation);
		TankToInstantiate.name = TankName;
		GameObject.Find (TankName).GetComponentInChildren<Canvas> ().enabled = true;
		CameraToSet = GameObject.Find (TankName ).GetComponentInChildren<Camera> ();
		CameraToSet.enabled = true;
		TankToInstantiate.GetComponentInChildren<Canvas> ().enabled = true;
	}


	public void StartUp () {
		SplashCam.enabled = false;
		print ("Startup actioned");
		MainCam.enabled = true;
		GameObject Tank;
		GameObject SpawnPoint;

		//Destroy any surviving tanks from a previous game. DestroyImmediate is used instead of Destroy, because Destroy waits until the end of the frame. 
		//This resulted in the Instantiate method failing unexpectedly - it created a new object, but kept the Camera enabled settings from previously.
		DestroyImmediate (GameObject.Find ("Blue_Tank_Old"));
		DestroyImmediate (GameObject.Find ("Red_Tank_Old"));
		DestroyImmediate(GameObject.Find ("Green_Tank_Old"));
		DestroyImmediate(GameObject.Find ("Yellow_Tank_Old"));


		Tank = GameObject.Find("Blue_Tank_Old");
		if (Tank !=null){
			//print(Tank.name);
		}
		
		/*
		SpawnPoint = GameObject.Find ("BlueSpawnPoint");
		BlueTank = Instantiate (BlueTankPrefab, SpawnPoint.transform.position, SpawnPoint.transform.rotation);
		BlueTank.name = "Blue_Tank_Old";
		GameObject.Find ("Blue_Tank_Old").GetComponentInChildren<Canvas> ().enabled = true;
		BluCam = GameObject.Find ("Blue_Tank_Old").GetComponentInChildren<Camera> ();
		*/
		//LoadPlayerTanks ("BlueSpawnPoint", "Blue_Tank_Old", ref BlueTankPrefab, ref BlueTank, ref BluCam);
		//LoadPlayerTanks ("RedSpawnPoint", "Red_Tank_Old", ref RedTankPrefab, ref RedTank, ref RedCam);
		//LoadPlayerTanks ("GreenSpawnPoint", "Green_Tank_Old", ref GreenTankPrefab, ref GreenTank, ref GrnCam);
		//LoadPlayerTanks ("YellowSpawnPoint", "Yellow_Tank_Old", ref YellowTankPrefab, ref YellowTank, ref YelCam);

		switch(PlayerCount){
		case 1:
			LoadPlayerTanks ("BlueSpawnPoint", "Blue_Tank_Old", ref BlueTankPrefab, ref BlueTank, ref BluCam);
			BluCam.rect = new Rect (0, 0, 1, 1);
			//print ("Blue Cam enabled status is " + BluCam.enabled);
			//GameObject.Find ("Blue_Tank_Old").GetComponentInChildren<Canvas> ().enabled = true;
			break;
		case 2:
			LoadPlayerTanks ("BlueSpawnPoint", "Blue_Tank_Old", ref BlueTankPrefab, ref BlueTank, ref BluCam);
			LoadPlayerTanks ("RedSpawnPoint", "Red_Tank_Old", ref RedTankPrefab, ref RedTank, ref RedCam);
			BluCam.rect = new Rect (0, 0, 1, 0.5f);
			RedCam.rect = new Rect (0f,0.5f,1f,0.5f);
			break;
		case 3:
			LoadPlayerTanks ("BlueSpawnPoint", "Blue_Tank_Old", ref BlueTankPrefab, ref BlueTank, ref BluCam);
			LoadPlayerTanks ("RedSpawnPoint", "Red_Tank_Old", ref RedTankPrefab, ref RedTank, ref RedCam);
			LoadPlayerTanks ("GreenSpawnPoint", "Green_Tank_Old", ref GreenTankPrefab, ref GreenTank, ref GrnCam);
			BluCam.rect = new Rect (0, 0, 1, 0.5f);
			RedCam.rect = new Rect (0f, 0.5f, 0.5f, 0.5f);
			GrnCam.rect = new Rect (0.5f, 0.5f, 0.5f, 0.5f);
			break;
		case 4:
			LoadPlayerTanks ("BlueSpawnPoint", "Blue_Tank_Old", ref BlueTankPrefab, ref BlueTank, ref BluCam);
			LoadPlayerTanks ("RedSpawnPoint", "Red_Tank_Old", ref RedTankPrefab, ref RedTank, ref RedCam);
			LoadPlayerTanks ("GreenSpawnPoint", "Green_Tank_Old", ref GreenTankPrefab, ref GreenTank, ref GrnCam);
			LoadPlayerTanks ("YellowSpawnPoint", "Yellow_Tank_Old", ref YellowTankPrefab, ref YellowTank, ref YelCam);
			BluCam.rect = new Rect (0, 0, 0.5f, 0.5f);
			RedCam.rect = new Rect (0f, 0.5f, 0.5f, 0.5f);
			GrnCam.rect = new Rect (0.5f, 0.5f, 0.5f, 0.5f);
			YelCam.rect = new Rect (0.5f, 0, 0.5f, 0.5f);
/*			BluCam.enabled = true;
			RedCam.enabled = true;
			GrnCam.enabled = true;
			YelCam.enabled = true;
			BluCam.rect = new Rect (0, 0, 0.5f, 0.5f);
			RedCam.rect = new Rect (0f, 0.5f, 0.5f, 0.5f);
			GrnCam.rect = new Rect (0.5f, 0.5f, 0.5f, 0.5f);
			YelCam.rect = new Rect (0.5f, 0, 0.5f, 0.5f);
			GameObject.Find ("Blue_Tank_Old").GetComponentInChildren<Canvas> ().enabled = true;
			GameObject.Find ("Red_Tank_Old").GetComponentInChildren<Canvas> ().enabled = true;
			GameObject.Find ("Green_Tank_Old").GetComponentInChildren<Canvas> ().enabled = true;
			GameObject.Find ("Yellow_Tank_Old").GetComponentInChildren<Canvas> ().enabled = true;
			*/
			break;
		}

		MainCam.enabled = false;
			
		Time.timeScale = 1; //start the game
		bGameIsLive = true;

		for (int i = 1; i<=numberOfTanks; i++)
		{
			GameObject new_tank = GameObject.Find ("GreyTank" + i);
			if (new_tank == null) {
				GameObject  spawnPoint = GameObject.Find ("SpawnPoint_Grey" + i) as GameObject;

				float f = Random.value;
				if (f < 0.25f) {
					GameObject Tanker = Instantiate (BigGreyTank, spawnPoint.transform.position, spawnPoint.transform.rotation) as GameObject;
					Tanker.name = "GreyTank" + i;
					Tanker.GetComponent<GreyTankMovement> ().Health = 2000;
					Tanker.GetComponent<GreyTankMovement> ().ShotPower = 300;
					Tanker.GetComponent<GreyTankMovement> ().Speed = 10;
				} else if (f > 0.62) {
					GameObject Tanker = Instantiate (GreyTank, spawnPoint.transform.position, spawnPoint.transform.rotation) as GameObject;
					Tanker.name = "GreyTank" + i;
					Tanker.GetComponent<GreyTankMovement> ().Health = 500;
					Tanker.GetComponent<GreyTankMovement> ().ShotPower = 100;
					Tanker.GetComponent<GreyTankMovement> ().Speed = 20;
				} else {
					GameObject Tanker = Instantiate (LittleGreyTank, spawnPoint.transform.position, spawnPoint.transform.rotation) as GameObject;
					Tanker.name = "GreyTank" + i;
					Tanker.GetComponent<GreyTankMovement> ().Health = 75;
					Tanker.GetComponent<GreyTankMovement> ().ShotPower = 50;
					Tanker.GetComponent<GreyTankMovement> ().Speed = 30;
				}
			}
		}
	}
		

	// Update is called once per frame
	void Update () {
		string OutPutScore;
		int intPlayersAlive;
		int intEnemiesAlive;

//		GameObject s;
		float f;
		if (GameMode == "Survival"){
			for (int i = 1; i <= numberOfTanks; i++) {
				GameObject new_tank = GameObject.Find ("GreyTank" + i);
				if (new_tank == null) {
					GameObject spawnPoint = GameObject.Find ("SpawnPoint_Grey" + i) as GameObject;
					GameObject Tank = Instantiate (GreyTank, spawnPoint.transform.position, spawnPoint.transform.rotation) as GameObject;
					Tank.GetComponent<GreyTankMovement> ().Health = 100;
					Tank.GetComponent<GreyTankMovement> ().ShotPower = 75;
					Tank.GetComponent<GreyTankMovement> ().Speed = 20;
					Tank.name = "GreyTank" + i;
				}
			}
		}

		if (bGameIsLive) {  //work out whether we should end the game. end if (1) timer runs out; (2) no players left, (3) only one player and no enemy tanks left.
			TimeLimit -= Time.deltaTime;
			//print (TimeLimit.ToString ());
			GameObject s = GameObject.FindGameObjectWithTag ("Timer");
			s.GetComponentInChildren<Text> ().text = TimeLimit.ToString ();
			if (TimeLimit < 0) {
				GameOver ();
			}
				

			intPlayersAlive = 0;
			intEnemiesAlive = 0;
			GameObject[] w = GameObject.FindGameObjectsWithTag ("Tank");
			foreach (GameObject y in w) {
//				print (y.name);
				if (y.name.EndsWith ("_Tank_Old")) {
					if (y.GetComponent<Damage> ().bCanMove == true) {
						//print ("Found alive one");
						intPlayersAlive++;
					}
				}
				if (y.name.StartsWith ("Grey")) {
					intEnemiesAlive++;
				}
			}

			//print ("Players alive: " + intPlayersAlive.ToString() + ", enemies alive: " + intEnemiesAlive.ToString());
			if (intPlayersAlive==0){
				GameOver();
			}
			if (intPlayersAlive == 1 && intEnemiesAlive == 0) {
				GameOver ();
			}

			GameObject[] p = GameObject.FindGameObjectsWithTag ("boom");
			foreach (GameObject go in p) {
				if (go.transform.parent == null) {
					Destroy (go, 3);
				}
			}
		}
	}

	public void ShowMainMenu(){
		bGameIsLive = false;
		print ("showing main menu ");
		ChangeCanvasDisplay ("GameOverTag", 0);
		ChangeCanvasDisplay ("HighScoreTag", 0);
		ChangeCanvasDisplay ("MainScreenTag", 1);
		ChangeCanvasDisplay ("NewHighScoreTag", 0);
	}

	public void ShowNewHighScore(){
		bGameIsLive = false;
		print ("showing new high scores");
		ChangeCanvasDisplay ("GameOverTag", 0);
		ChangeCanvasDisplay ("HighScoreTag", 0);
		ChangeCanvasDisplay ("MainScreenTag", 0);
		ChangeCanvasDisplay ("NewHighScoreTag", 1);
	}

	public void ShowHighScores(){
		bGameIsLive = false;
		print ("showing high scores");
		ChangeCanvasDisplay ("GameOverTag", 0);
		ChangeCanvasDisplay ("HighScoreTag", 1);
		ChangeCanvasDisplay ("MainScreenTag", 0);
		ChangeCanvasDisplay ("NewHighScoreTag", 0);

		for (int i = 0; i <= 9; i++) {
			GameObject.Find ("PlayerName" + i.ToString()).GetComponent<Text> ().text = HighPlayers[i];
			GameObject.Find ("PlayerScore"+i.ToString()).GetComponent<Text> ().text = HighValues[i];
		}
	}

	public void ShowGameOver(){
		string strTemp;
		bGameIsLive = false;
		print ("showing game over");
		ChangeCanvasDisplay ("GameOverTag", 1);
		ChangeCanvasDisplay ("HighScoreTag", 0);
		ChangeCanvasDisplay ("MainScreenTag", 0);
		ChangeCanvasDisplay ("NewHighScoreTag", 0);

		//ScoreArray is now sorted from 0 (Smalles) to 3 (Biggest)
		//Clear out the old game results
		GameObject.Find ("gPlayerName1").GetComponent<Text> ().text = "";
		GameObject.Find ("gPlayerScore1").GetComponent<Text> ().text = "";
		GameObject.Find ("gPlayerName2").GetComponent<Text> ().text = "";
		GameObject.Find ("gPlayerScore2").GetComponent<Text> ().text = "";
		GameObject.Find ("gPlayerName3").GetComponent<Text> ().text = "";
		GameObject.Find ("gPlayerScore3").GetComponent<Text> ().text = "";
		GameObject.Find ("gPlayerName4").GetComponent<Text> ().text = "";
		GameObject.Find ("gPlayerScore4").GetComponent<Text> ().text = "";


		//now put in the game scores for the number of players that were active
		for (int i = 0; i <PlayerCount ; i++) {
			//print (GameObject.Find ("gPlayerName" + (i + 1)).name);
			//print (GameObject.Find ("gPlayerScore" + (i + 1)).name);
			GameObject.Find ("gPlayerName" + (i + 1)).GetComponent<Text> ().text = ScoreArray [i, 0];
			GameObject.Find ("gPlayerScore" + (i + 1)).GetComponent<Text> ().text = ScoreArray [i, 1];
		}
		 

/*		switch (PlayerCount){
		case 1:
		case 3:
		case 4:
			GameObject.Find ("gPlayerName1").GetComponent<Text> ().text = "Blue Player";
			GameObject.Find ("gPlayerScore1").GetComponent<Text> ().text = GameObject.Find ("Blue_Tank_Old").GetComponent<Damage> ().Score.ToString();
			GameObject.Find ("gPlayerName2").GetComponent<Text> ().text = "Red Player";
			GameObject.Find ("gPlayerScore2").GetComponent<Text> ().text = GameObject.Find ("Red_Tank_Old").GetComponent<Damage> ().Score.ToString();
			GameObject.Find ("gPlayerName3").GetComponent<Text> ().text = "Green Player";
			GameObject.Find ("gPlayerScore3").GetComponent<Text> ().text = GameObject.Find ("Green_Tank_Old").GetComponent<Damage> ().Score.ToString();
			GameObject.Find ("gPlayerName4").GetComponent<Text> ().text = "Yellow Player";
			GameObject.Find ("gPlayerScore4").GetComponent<Text> ().text = GameObject.Find ("Yellow_Tank_Old").GetComponent<Damage> ().Score.ToString();
			break;
		}
*/
	}

	void GameEnding()
	{
		//load up the player scores into an array of scores for sorting. A switch statement doesn't work because C# switch doesn't allow fall-through.
		//this is quite messy, I need to think of a way to clean it up. 
		//part of the problem is that in Survival, high scores are good, and in Last Tank Standing low scores are good.

		if (GameMode == "Survival") {
			if (PlayerCount == 4) {
				ScoreArray [3, 0] = GameObject.Find ("Yellow_Tank_Old").GetComponent<Damage> ().Score.ToString ();
				ScoreArray [3, 0] = GameObject.Find ("Yellow_Tank_Old").GetComponent<Damage> ().intRank.ToString ();
			}
			if (PlayerCount >= 3) {
				ScoreArray [2, 0] = GameObject.Find ("Green_Tank_Old").GetComponent<Damage> ().Score.ToString ();
			}
			if (PlayerCount >= 2) {
				ScoreArray [1, 0] = GameObject.Find ("Red_Tank_Old").GetComponent<Damage> ().Score.ToString ();
			}
			ScoreArray [0, 0] = GameObject.Find ("Blue_Tank_Old").GetComponent<Damage> ().Score.ToString ();
		} else {
			if (PlayerCount == 4) {
				ScoreArray [3, 0] = GameObject.Find ("Yellow_Tank_Old").GetComponent<Damage> ().intRank.ToString ();
			}
			if (PlayerCount >= 3) {
				ScoreArray [2, 0] = GameObject.Find ("Green_Tank_Old").GetComponent<Damage> ().intRank.ToString ();
			}
			if (PlayerCount >= 2) {
				ScoreArray [1, 0] = GameObject.Find ("Red_Tank_Old").GetComponent<Damage> ().intRank.ToString ();
			}
			ScoreArray [0, 0] = GameObject.Find ("Blue_Tank_Old").GetComponent<Damage> ().intRank.ToString ();
		}


/*		for (int i = 0; i <= 3; i++) {
			if (ScoreArray [i, 0] == null) {
				switch (GameMode ) {
				case "Survival":
					ScoreArray [i, 0] = "0";
					break;
				default:
					ScoreArray [i, 0] = "25";
					break;
				}
			}
		}*/

		ScoreArray [0, 1] = "Blue Player";
		ScoreArray [1, 1] = "Red Player";
		ScoreArray [2, 1] = "Green Player";
		ScoreArray [3, 1] = "Yellow Player";

		//print ("got this far");
		//print ("check");

		if (GameMode == "Survival") {
			//print ("check");
			BubbleSortHighToLow (ScoreArray);
			print (ScoreArray [0, 0]);
			print (HighValues [9]);
			//print ("check");
			if (int.Parse(ScoreArray[0,0]) > int.Parse(HighValues[9])) {
				//print ("check");
				ShowNewHighScore(); //open a dialog for the best player to enter their score.
				//ShowGameOver();		
			}
			else {
				//print ("check");
				ShowGameOver();
			}
		}
		else
		{
			//print ("check");
			BubbleSortLowToHigh (ScoreArray);
			//print ("check");
			ShowGameOver();		
		}
	}

	void LoadHighScores(){
		//load up the high scores table. This will give 2 arrays - HighPlayers(10) and HighValues(10).
		//string[] strTemp;
		strFileDataPath = Path.GetDirectoryName (Application.dataPath) + "/HighScores.txt";
		//print (strFileDataPath);
		string[] strText = File.ReadAllLines  (strFileDataPath);
		for (int i = 0; i <= 9; i++) {
			//print (strText [i]);
			string [] strTemp = strText[i].Split(',');
			//print (strTemp[0]);
			//print (strTemp[1]);
			//print (HighValues.GetLowerBound(0));
			HighValues[i] = strTemp[0];
			HighPlayers[i] = strTemp[1];
			//print (HighPlayers[i]);
			//print (HighValues[i]);
			//print ("----------");
		}
	}

	public void UpdateHighScores(){
		int tmpScore;
		string tmpName;
		tmpScore = int.Parse (ScoreArray [0, 0]);
		tmpName = GameObject.Find ("NewHighScoreInputText").GetComponentInChildren<Text>().text;

		for (int i = 0; i <= 9; i++) {
			if(tmpScore>int.Parse(HighValues[i])){
				for (int j = 8 ; j >=i; j--) {
					HighValues [j + 1] = HighValues [j];
					HighPlayers [j + 1] = HighPlayers [j];
				}
				HighValues [i] = tmpScore.ToString ();
				HighPlayers [i] = tmpName;
				break;
			}
		}
		//write back to the high score table
		SaveHighScores();
		ShowHighScores();
	}

	void SaveHighScores(){
		//load up the high scores table. This will give 2 arrays - HighPlayers(10) and HighValues(10).
		string strTemp;
		strTemp = "";
		strFileDataPath = Path.GetDirectoryName (Application.dataPath) + "/HighScores.txt";

		//print (strFileDataPath);
		string[] strText = File.ReadAllLines (strFileDataPath);

		for (int i = 0; i <= 9; i++) {
			strTemp = strTemp + HighValues [i] + "," + HighPlayers [i] + "\r\n"; // \r\n means carriage return and new line
		}
		File.WriteAllText (strFileDataPath, strTemp);
	}

	void ChangeCanvasDisplay(string strChangeTag, int intValue){
		GameObject[] xx; //an array of gameobjects that we'll put the game object's with the relevant tag into.
		xx = GameObject.FindGameObjectsWithTag(strChangeTag);
		foreach(GameObject yy in xx){
			yy.transform.localScale = new Vector3 (intValue, intValue, intValue);
		}
	}
		
	void GameOver(){
		//print (TimeLimit.ToString ());
		Time.timeScale = 0;
		SplashCam.enabled = true;
		MainCam.enabled = false;
		switch (PlayerCount)
		{
		case 1:
			BluCam.enabled = false;
			GameObject.Find ("Blue_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
			break;
		case 2:
			BluCam.enabled = false;
			RedCam.enabled = false;
			GameObject.Find ("Blue_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
			GameObject.Find ("Red_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
			break;
		case 3:
			BluCam.enabled = false;
			RedCam.enabled = false;
			GrnCam.enabled = false;
			GameObject.Find ("Blue_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
			GameObject.Find ("Red_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
			GameObject.Find ("Green_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
			break;
		case 4:
			BluCam.enabled = false;
			RedCam.enabled = false;
			GrnCam.enabled = false;
			YelCam.enabled = false;
			GameObject.Find ("Blue_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
			GameObject.Find ("Red_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
			GameObject.Find ("Green_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
			GameObject.Find ("Yellow_Tank_Old").GetComponentInChildren<Canvas> ().enabled = false;
			break;
		}
		GameEnding ();

	}

	void BubbleSortHighToLow( string[,] ScoreArray)
	{
		string strTemp0;
		string strTemp1;
		bool bSwap;
		do { //bubble sort biggest to smallest
			bSwap = false;
			for (int i=0; i<(PlayerCount-1);i++)
			{
				if(int.Parse (ScoreArray[i,0])<int.Parse(ScoreArray[i+1,0])){
					strTemp0 = ScoreArray[i,0];
					strTemp1 = ScoreArray[i,1];
					ScoreArray[i,0] = ScoreArray[i+1,0];
					ScoreArray[i,1] = ScoreArray[i+1,1];
					ScoreArray[i+1,0]= strTemp0;
					ScoreArray[i+1,1]=strTemp1;
					bSwap=true;
				}
			}
		} while (bSwap==true);
	}

	void BubbleSortLowToHigh(string[,] ScoreArray)
	{
		string strTemp0;
		string strTemp1;
		bool bSwap;
		/*		print ("BA");
		print (ScoreArray [0, 0]);
		print (ScoreArray [0, 1]);
		print (ScoreArray [1, 0]);
		print (ScoreArray [1, 1]);
		print (ScoreArray [2, 0]);
		print (ScoreArray [2, 1]);
		print (ScoreArray [3, 0]);
		print (ScoreArray [3, 1]);
*/
		do { //bubble sort biggest to smallest
			bSwap = false;
			for (int i=0; i<PlayerCount-1;i++)
			{
				if(int.Parse (ScoreArray[i,0])>int.Parse(ScoreArray[i+1,0])){
					strTemp0 = ScoreArray[i,0];
					strTemp1 = ScoreArray[i,1];
					ScoreArray[i,0] = ScoreArray[i+1,0];
					ScoreArray[i,1] = ScoreArray[i+1,1];
					ScoreArray[i+1,0]= strTemp0;
					ScoreArray[i+1,1]=strTemp1;
					bSwap=true;
				}
			}
		} while (bSwap==true);
	}

	public void QuitButton(){
		print ("Quitting");
		Application.Quit ();
	}

	public int TanksLeft (){
		int intTankCount;
		intTankCount = 0;//start at 1, because the player tank that just died still counts.
		GameObject[] xx; //an array of gameobjects that we'll put the game object's with the relevant tag into.
		xx = GameObject.FindGameObjectsWithTag("Tank");
		foreach(GameObject yy in xx){
			if (yy.name.EndsWith ("_Tank_Old")) { //this is a player tank. Check if it can still move (i.e. it's live)
				if (yy.GetComponentInChildren<Damage> ().bCanMove == true) {
					intTankCount++;
					print (yy.name);
				}
			} 
			else {// it's a computer tank. no need to check any further
				print(yy.name);
				intTankCount++;
			}
		}
		return intTankCount;
	}

}