﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreenBullet_fire : MonoBehaviour {
	public AudioClip shotFire;
	public AudioSource FiringSource;
	public bool bLiveBullet = false;
	public Rigidbody bullet;
	public Transform bullet_transform;
	public float bulletSpeed ;

	// Use this for initialization
	void Start () {
		FiringSource.clip = shotFire;
	}

	// Update is called once per frame
	void Update () {
		if (gameObject.GetComponentInChildren<Damage> ().bCanScore == true) {
			if (Input.GetKey (KeyCode.Space)) {
				if (!bLiveBullet) {
					Shoot ();
				}
			}
		}

		if (Input.GetKey(KeyCode.I)) {
			print ("Bullet_transform position: " + bullet_transform.position);
		}

	}

	void Shoot()
	{
		Rigidbody newBullet = Instantiate (bullet, bullet_transform.position, bullet_transform.rotation) as Rigidbody;
		newBullet.velocity = bulletSpeed * bullet_transform.forward;
		newBullet.name = gameObject.name + "Bullet";
		bLiveBullet = true;
		newBullet.gameObject.GetComponent<BulletCollider> ().ShellShotPower = gameObject.GetComponent<GreenTankMovement> ().ShotPower;
		FiringSource.Play ();
	}
}