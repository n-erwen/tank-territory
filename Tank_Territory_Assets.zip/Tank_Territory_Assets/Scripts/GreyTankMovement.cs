﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GreyTankMovement : MonoBehaviour {
	public float Health;
	public float ShotPower;
	public float Speed;
	public bool bLiveBullet = false;
	public bool bMovingForward = true ;
	public string myTargetName;
	public bool bMovingLeft = false ;
	private Rigidbody myRigidbody;
	public float mySpeed;
	private float myTurnDirection;
	public float myTurningSpeed = 105f;
	public bool b_fired = false;
	public Rigidbody bullet;
	public Transform bullet_transform;
	public float bulletSpeed ;

		// Use this for initialization
		void Start () {
			int fForwardBack;
			int fLeftRight;
			myRigidbody = GetComponent<Rigidbody> ();

			fForwardBack = Random.Range(0,11);
			fLeftRight= Random.Range(0,11);

			if (fForwardBack>5) {bMovingForward = false;}
			if (fLeftRight>5) {bMovingLeft = true;}
		}


		// Update is called once per frame
		void Update () {
		if (Health < 0) {
			Destroy (gameObject,1);
		}
		if (bLiveBullet) {
			EvasiveMove ();
		} else {
			BeAggressive ();
		}

	}

	private void BeAggressive()
	{

		RaycastHit hit;
		// raycast - can I see a target?
		if (Physics.Raycast (myRigidbody.position, myRigidbody.transform.forward, out hit, 200f)) {
			//print ("I spotted a " + hit.collider.tag);
			if ((hit.collider.tag == "Tank") || (hit.collider.tag == "PlayerTank")) {
				if (hit.distance < 100f) { //in range?
					//in range! Fire!
					//print ("I want to shoot at " + hit.collider.name);
					Shoot ();
				} else {
					//Out of range - move toward target.
					myTargetName = hit.collider.name ;  //use this to hunt afterwards, not raycasting
					Move(Speed);
				}
			}
			else{
				//if I can't see a target, move in a big left circle)*/
				Move (Speed);
				Turn (-1f, myTurningSpeed);
			}
		} else {
			//if I can't see a target, move in a big left circle)*/
			Move (Speed);
			Turn (-1f, myTurningSpeed);
		}
		  
	}

	private void EvasiveMove()
	{
		int RandomNumber;

		//Forward backness
		RandomNumber = Random.Range(1,1001);
		if(RandomNumber>=995) 
		{
			bMovingForward = !bMovingForward;
		}
		//left rightness
		RandomNumber = Random.Range(1,11);
		if(RandomNumber>=9) 
		{
			bMovingLeft = !bMovingLeft;
		}

		if (bMovingForward) 
		{
			mySpeed = Speed;
		}
		else {
			mySpeed = -Speed;
		}

		if (bMovingLeft) 
		{
			myTurnDirection = -1f;
		}
		else {
			myTurnDirection = 1f;
		}

		Move (mySpeed);
		Turn (myTurnDirection, myTurningSpeed);
	}

		
		private void Move(float mySpeed)
		{
			// Create a vector in the direction the tank is facing with a magnitude based on the input, speed and the time between frames.
			Vector3 movement = transform.forward *  mySpeed * Time.deltaTime;

			// Apply this movement to the rigidbody's position.
			myRigidbody.MovePosition(myRigidbody.position + movement);
		}


		void OnCollisionEnter(Collision collision) {
			//print ("collided with " + collision.collider.ToString ());
		if (collision.collider.tag == "Wall") {
			bMovingForward = !bMovingForward;
		}


		}		


		private void Turn (float myTurnDirection, float myTurningSpeed)
		{
			// Determine the number of degrees to be turned based on the input, speed and time between frames.
			float turn = myTurnDirection * myTurningSpeed * Time.deltaTime;

			// Make this into a rotation in the y axis.
			Quaternion turnRotation = Quaternion.Euler (0f, turn, 0f);

			// Apply this rotation to the rigidbody's rotation.
			myRigidbody.MoveRotation (myRigidbody.rotation * turnRotation);
		}
		

	void Shoot()
	{
		Rigidbody newBullet = Instantiate (bullet, bullet_transform.position, bullet_transform.rotation) as Rigidbody;
		newBullet.velocity = bulletSpeed * bullet_transform.forward;
		newBullet.name = gameObject.name + "Bullet";
		bLiveBullet = true;
		newBullet.gameObject.GetComponent<BulletCollider>().ShellShotPower = ShotPower;

	}
}
