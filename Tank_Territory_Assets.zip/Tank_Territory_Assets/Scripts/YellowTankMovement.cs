﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class YellowTankMovement : MonoBehaviour 
{
	public float ShotPower;
	public float Speed;
	public int FlagCount = 0;
	private Rigidbody myRigidbody;
	public float mySpeed;
	private float myTurnDirection;
	public float myTurningSpeed = 105f;

	// Use this for initialization
	void Start () {
		myRigidbody = GetComponent<Rigidbody> ();
	}

	// Update is called once per frame
	void Update () {
		if (gameObject.GetComponentInChildren<Damage> ().bCanMove == true) {
			if (Input.GetKey (KeyCode.Keypad8)) {
				// this is where I move forward
				mySpeed = 20.0f;
				Move (mySpeed);
			}

			if (Input.GetKey (KeyCode.Keypad5)) {
				mySpeed = -20.0f;
				Move (mySpeed);
			}
			if (Input.GetKey (KeyCode.Keypad4)) {
				//rotate left
				myTurnDirection = -1f;
				Turn (myTurnDirection, myTurningSpeed);
			}

			if (Input.GetKey (KeyCode.Keypad6)) {
				//rotate right
				myTurnDirection = 1f;
				Turn (myTurnDirection, myTurningSpeed);
			}

			//		if (Input.GetKey (KeyCode.RightShift)) {
			//			//This will destroy the tank!
			//			Destroy (gameObject);
			//		}

			/*if (Input.GetKey (KeyCode.R)) {
			//test raycast
			Debug.DrawRay(myRigidbody.position ,myRigidbody.transform.forward * 100f, Color.red);
			print (myRigidbody.name) ;
			print (myRigidbody.transform.position);
		}*/
		}
	}

	private void Move(float mySpeed)
	{
		// Create a vector in the direction the tank is facing with a magnitude based on the input, speed and the time between frames.
		Vector3 movement = transform.forward *  mySpeed * Time.deltaTime;

		// Apply this movement to the rigidbody's position.
		myRigidbody.MovePosition(myRigidbody.position + movement);
	}


	void OnCollisionEnter(Collision coll) {
		//print ("collided with " + collision.collider.ToString ());
		//print ("collided with " + collision.collider.tag);
		GameObject g;
		//print (coll.gameObject.name);
		if (coll.gameObject.tag == "FlagPole") {
			FlagCount++;
			print ("i hit " );
			Destroy (coll.transform.parent.gameObject );
			g = GameObject.Find ("GameManager");
//			g.GetComponent<GameManager>().BluScore =g.GetComponent<GameManager>().BluScore + 3; 
			//Destroy (collision.collider, 0);
		}
	}		


	private void Turn (float myTurnDirection, float myTurningSpeed)
	{
		// Determine the number of degrees to be turned based on the input, speed and time between frames.
		float turn = myTurnDirection * myTurningSpeed * Time.deltaTime;

		// Make this into a rotation in the y axis.
		Quaternion turnRotation = Quaternion.Euler (0f, turn, 0f);

		// Apply this rotation to the rigidbody's rotation.
		myRigidbody.MoveRotation (myRigidbody.rotation * turnRotation);
	}




}
