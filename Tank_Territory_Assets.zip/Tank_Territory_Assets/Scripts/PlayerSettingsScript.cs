﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; //this one had to be added in so we can reference the Settings Dropdowns

public class PlayerSettingsScript : MonoBehaviour {
	public Dropdown dropdownGameTime;
	public Dropdown dropdownPlayerCount;
	public Dropdown dropdownAICount;
	public Dropdown dropdownGameMode;

	public int numberOfTanks = 20;
	public int numberOfActiveTanks = 19;
	public int TimeLimit;
	public int PlayerCount = 1;
	public string GameMode = "Last Tank Standing";// could also be "Survival"

	public void LoadSettings()
	{
		TimeLimit = int.Parse (dropdownGameTime.GetComponentInChildren<Text> ().text);
		PlayerCount= int.Parse(dropdownPlayerCount.GetComponentInChildren<Text> ().text);
		numberOfTanks = int.Parse(dropdownAICount.GetComponentInChildren<Text> ().text);
		if (dropdownGameMode.value == 1) {
			GameMode = "Last Tank Standing";
		}
		else {
			GameMode = "Survival";
		}
		print (numberOfTanks);
		print (TimeLimit);
		print (PlayerCount);
		print (GameMode);

		GameObject g = GameObject.Find ("GameManager");

	}

	// Use this for initialization
	void Start () {
	}

	// Update is called once per frame
	void Update () {
		
	}
}
