﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletCollider : MonoBehaviour {
	public LayerMask m_TankMask;                        // Used to filter what the explosion affects, this should be set to "Players".
	public ParticleSystem m_ExplosionParticles;         // Reference to the particles that will play on explosion.
	public float m_MaxLifeTime = 10f;                    // The time in seconds before the shell is removed.
	public float ShellShotPower;
	public AudioClip shellBoom;
	public AudioSource BoomSource;

	// Use this for initialization
	void Start () {
		
	}

	void OnTriggerEnter (Collider coll) {
		
		string whoFiredMe;

		//GameObject pBoomBoom = GameObject.Find ("Fx_OilSplashHIGH_Root");
		//pBoomBoom.Play();
		//ParticleSystem pBang = Instantiate (pBoomBoom, gameObject.transform.position, gameObject.transform.rotation ) as ParticleSystem;
		//pBang.Play();
//		Fx_OilSplashHIGH_Root

		ParticleSystem pBoom = Instantiate (m_ExplosionParticles, gameObject.transform.position, gameObject.transform.rotation ) as ParticleSystem;
				// Unparent the particles from the shell.
				//m_ExplosionParticles.transform.parent = null;
		//pBoom.transform.localScale = new Vector4(1, pBoom.transform.localScale.x,pBoom.transform.localScale.y,pBoom.transform.localScale.z);
		pBoom.Play();
		pBoom.transform.parent = null;
		BoomSource.Play ();
		//Destroy (pBoom, 3f);

		//whoever shot can shoot again.
		whoFiredMe = gameObject.name;
		whoFiredMe = whoFiredMe.Replace ("Bullet", "");

		GameObject b = GameObject.Find (whoFiredMe);
		GameObject g = GameObject.Find ("GameManager");


		// This is the modified part:
		float  radius = 5.0f;
		float power = 10.0f;
		float totaldamage = 0f;
		Vector3 explosionPos = transform.position;
		Collider[] colliders = Physics.OverlapSphere (explosionPos, radius);
			foreach (Collider hit in colliders) {
				if (!hit) continue; // avoid null references (should not occur, but...)
			if (hit.tag == "Tank"){
				//print("i hit a tank and my strength is" & shotPower
//				print("I hit a tank");
				//print (hit.name);
//				Destroy (hit.transform.parent );
				float distance = Vector3.Distance(hit.transform.position, transform.position);
				float damage = 3.3f / distance ; 
				damage = damage * ShellShotPower;
//				print ("Distance " + distance.ToString() + "; Shot Power " + ShellShotPower.ToString() + "; damage" + damage.ToString());
//				print (ShellShotPower);
//				print (damage);
				if (hit.name.StartsWith ("GreyTank")){
					GameObject V = hit.gameObject;
					V.GetComponent<GreyTankMovement> ().Health = V.GetComponent<GreyTankMovement> ().Health - damage;
					totaldamage = totaldamage + damage;
				}
				if (hit.name.StartsWith ("Red")){
				GameObject V = hit.gameObject;
				V.GetComponent<Damage> ().TakeDamage (damage);
					totaldamage = totaldamage + damage;
				}
				if (hit.name.StartsWith ("Blue")){
					GameObject V = hit.gameObject;
					V.GetComponent<Damage> ().TakeDamage (damage);
					totaldamage = totaldamage + damage;
				}
				if (hit.name.StartsWith ("Green")){
					GameObject V = hit.gameObject;
					V.GetComponent<Damage> ().TakeDamage (damage);
					totaldamage = totaldamage + damage;
				}
				if (hit.name.StartsWith ("Yellow")){
					GameObject V = hit.gameObject;
					V.GetComponent<Damage> ().TakeDamage (damage);
					totaldamage = totaldamage + damage;
				}

//				hit.GetComponent<Rigidbody>.addexplosionforce(power, explosionPos, radius, 3.0);
			}
		}

		if (whoFiredMe.StartsWith ("Blue") || whoFiredMe.StartsWith ("Red") || whoFiredMe.StartsWith ("Green") || whoFiredMe.StartsWith ("Yellow") ) {
			//print (whoFiredMe);
			b.GetComponentInChildren<Damage> ().DoDamage ((int)totaldamage);
		}

		gameObject.GetComponent<Rigidbody> ().AddExplosionForce (1000.0f, transform.position,10.0f,2.0f );



		// find the colliders inside a sphere of radius farAreaEffect
//		var colls[] = Physics.OverlapSphere(transform.position, 100);
//		for (var col: Collider in colls){
//			if (col.tag == "British"){ // if it's a bloody British...
		// calculate the distance from the impact...
//				var distance = Vector3.Distance(col.transform.position, transform.position);
//				var damage = farDamage; // assume farDamage initially...
//				if (distance <= closeAreaEffect){
//					damage = closeDamage; // but if inside close area, change to max damage
//				else 
//					if (distance <= mediumAreaEffect){
//						damage = mediumDamage; // else if inside medium area, change to medium damage
//					}
		// apply the selected damage
//				col.SendMessage("ApplyDamage", damage, SendMessageOptions.DontRequireReceiver);
//			}
//		}


		if (coll.tag == "Tank") {
//			print ("Tank " + coll.name + " hit by " + gameObject.name);
			GameObject t = GameObject.Find (coll.name);

//	Not using this any more - now look at the update for the tank, and destroy it if the health is less than 0
//	Destroy (t);

			if (whoFiredMe.StartsWith ("Red")){
				g.GetComponent<GameManager> ().RedScore = g.GetComponent<GameManager> ().RedScore+10;
			}
			if (whoFiredMe.StartsWith ("Blue")){
				g.GetComponent<GameManager>().BluScore = g.GetComponent<GameManager>().BluScore+10;
			}
			if (whoFiredMe.StartsWith ("Green")){
				g.GetComponent<GameManager>().GrnScore = g.GetComponent<GameManager>().GrnScore +10;
			}
			if (whoFiredMe.StartsWith ("Yellow")){
				g.GetComponent<GameManager>().YelScore = g.GetComponent<GameManager>().YelScore+10;
			}
		}

		if (coll.tag == "PlayerTank") {
			if (whoFiredMe.StartsWith ("Grey")) {
				if (coll.name.StartsWith("Red") ){
					g.GetComponent<GameManager> ().RedScore = g.GetComponent<GameManager> ().RedScore-5;
				}
				else
				{
					g.GetComponent<GameManager> ().BluScore = g.GetComponent<GameManager>().BluScore-5;
				}
			}
			else {
			}
			if (whoFiredMe.StartsWith("Red") && coll.name.StartsWith("Blue")) {
				g.GetComponent<GameManager> ().RedScore = g.GetComponent<GameManager> ().RedScore+10;
				g.GetComponent<GameManager> ().BluScore = g.GetComponent<GameManager>().BluScore-10;
			}
			if (whoFiredMe.StartsWith("Blue") && coll.name.StartsWith("Red")) {
				g.GetComponent<GameManager> ().RedScore = g.GetComponent<GameManager> ().RedScore-10;
				g.GetComponent<GameManager> ().BluScore = g.GetComponent<GameManager>().BluScore+10;
				}

		}

		if (b != null) {
			if (whoFiredMe.StartsWith("Grey")) {
					b.GetComponent<GreyTankMovement>().bLiveBullet = false;
				}
			if (whoFiredMe.StartsWith ("Red")){
					b.GetComponent<RedBullet_fire>().bLiveBullet = false;
				}
			if (whoFiredMe.StartsWith ("Green"))
				{
					b.GetComponent<GreenBullet_fire>().bLiveBullet = false;
				}
			if (whoFiredMe.StartsWith ("Blue"))
				{
					b.GetComponent<BlueBullet_fire>().bLiveBullet = false;
				}
			if (whoFiredMe.StartsWith ("Yellow"))
				{
					b.GetComponent<YellowBullet_fire>().bLiveBullet = false;
				}
				
					}
			
		Destroy(gameObject);
	}

	void OnCollisionEnter (Collision hit) {
		print ("Collsision boom");
	}


	// Update is called once per frame
	void Update () {
		
	}
}
