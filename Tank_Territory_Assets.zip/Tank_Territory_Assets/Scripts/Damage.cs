﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Damage : MonoBehaviour {
	public bool bCanMove = true;
	public float Score=0;
	public float MaxHealth=1000;
	public float Health=1000;
	public bool bCanScore = true;
	public int intRank = 1;

	void Update(){
		if (Health <= 0 && bCanMove) {
//			Destroy (gameObject);
			bCanMove = false;
			bCanScore = false;
			print ("----------- calculating for" + gameObject.name + " --------------");
			intRank = intRank + GameObject.Find ("GameManager").GetComponentInChildren<GameManager> ().TanksLeft ();
			print (gameObject.name +" ranks " + intRank);
		}
	}

	public void DoDamage (float DamageGiven){
		Score = Score + DamageGiven;
		gameObject.GetComponentInChildren<Text> ().text = Score.ToString();
	}

	public void TakeDamage (float DamageTaken){
		Health = Health - DamageTaken;
		if (Health >= 0) {
			gameObject.GetComponentInChildren<Slider>().value = Health/MaxHealth;
		}

	}
		
}
